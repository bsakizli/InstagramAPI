<?php
try {
     $db = new PDO("mysql:host=localhost;dbname=instagram", "root", "");
} catch ( PDOException $e ){
     print $e->getMessage();
}
