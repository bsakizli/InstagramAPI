<?php 
include("mail.php");

require __DIR__ . '/vendor/autoload.php';

// unofficial bir api olduğu için riskleri kabul ettiğimizi onaylıyoruz
\InstagramAPI\Instagram::$allowDangerousWebUsageAtMyOwnRisk = true;

// instagram kullanıcı adınız
$username = 'bsakizli';

// instagram şifreniz
$password = 'Bar@K59!';

// debug açık ise detayları görürsünüz, tercih size kalmış.
$debug = false;
$truncatedDebug =false;

// kullanacağımız sınıfı başlatıyoruz
$ig = new \InstagramAPI\Instagram($debug, $truncatedDebug);

try {
    $ig->login($username, $password);
} catch (\Exception $e) {
    die('Bir hata oluştu: ' . $e->getMessage());
}

$current = $ig->account->getCurrentUser();
$Response =  $current->getUser();
$Result = json_decode($Response,true);
echo $Result["biography"];


?>