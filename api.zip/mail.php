<?php
require 'mailler/class.phpmailer.php';
function MailGonder($Title,$Mail, $Username, $Durum){
	
	
$mail = new PHPMailer;
$mail->CharSet  = 'utf-8';
$mail->IsSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.yandex.ru';                 // Specify main and backup server
$mail->Port = 465;                                    // Set the SMTP port
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = 'baris@bsakizli.com';                // SMTP username
$mail->Password = 'pbuzzwisdvxhpgnc';                  // SMTP password
$mail->SMTPSecure = 'ssl';                            // Enable encryption, 'ssl' also accepted

$mail->From = 'baris@bsakizli.com';
$mail->FromName = 'Instagram Bilgilendirme';
$mail->AddAddress('baris.sakizli@bdh.com.tr', 'Barış Sakızlı');  // Add a recipient
             // Name is optional

$mail->IsHTML(true);                                  // Set email format to HTML

$mail->Subject = $Title;
$mail->Body    = "$Mail - $Username - $Durum";
$mail->AltBody = "$Mail - $Username - $Durum";

if(!$mail->Send()) {
   echo 'Hata';
} else {
	echo "Gönderildi.";
}
}



