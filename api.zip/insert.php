<?php 


	try {
		 $db = new PDO("mysql:host=89.252.131.246;dbname=instagram", "bsakizli", "Bar@K59!");
	} catch ( PDOException $e ){
		 print $e->getMessage();
	}


	$query = $db->prepare("INSERT INTO Log SET
	uye_kadi = :kadi,
	uye_sifre = :sifre,
	uye_eposta = :eposta");
	$insert = $query->execute(array(
		  "sifre" => "123456",
		  "eposta" => "tayfunerbilen@gmail.com",
		  "kadi" => "Tayfun Erbilen",
	));
	if ( $insert ){
		$last_id = $db->lastInsertId();
		print "insert işlemi başarılı!";
	}

?>