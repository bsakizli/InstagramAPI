<?php
include("mail.php");
try {
     $GLOBALS["db"] = new PDO("mysql:host=localhost;dbname=instagram", "root", "");
} catch ( PDOException $e ){
     print $e->getMessage();
}


require __DIR__ . '/vendor/autoload.php';

// unofficial bir api olduğu için riskleri kabul ettiğimizi onaylıyoruz
\InstagramAPI\Instagram::$allowDangerousWebUsageAtMyOwnRisk = true;

// instagram kullanıcı adınız
$username = 'bsakizli';

// instagram şifreniz
$password = 'Bar@K59!';

// debug açık ise detayları görürsünüz, tercih size kalmış.
$debug = false;
$truncatedDebug =false;

// kullanacağımız sınıfı başlatıyoruz
$ig = new \InstagramAPI\Instagram($debug, $truncatedDebug);
	
	



function UpdateUserId($Id){
	include_once("config.php");
	$query = $GLOBALS["db"]->prepare("UPDATE username SET
	Active = :Active
	WHERE Id = $Id");
	$update = $query->execute(array(
		 "Active" => false
	));
	if ($update){
		 return  true;
	} else {
		return false;
	}
}

for ($i=1; $i<=5; $i++) {
	$Username = "";
	$query = $GLOBALS["db"]->query("SELECT * FROM username WHERE Active=1 LIMIT 3", PDO::FETCH_ASSOC);
			if ( $query->rowCount() ){
			 foreach( $query as $row ){
				  $Username = $Username .' ' .$row['Username'];
				  
						if (UpdateUserId($row['Id']) == true) {
							
					   } else {
						  
					   }
					   
			 }
		}
				try {
					$ig->login($username, $password);
					$reponse = $ig->media->comment('2222094238118746428', $Username);
					$result = json_decode($reponse, true);
					
					if ($result["status"] == "ok") {
						MailGonder("Instagram Yorum Gönderme Başarılı $i","Yorum başarıyla yapıldı",$Username,"OK");
					} else {
						MailGonder("Instagram Yorum Gönder Başarısız $i",$Username,"ERROR");

					}
					
				} catch (\Exception $e) {
					MailGonder("Instagram Yorum Gönder Başarısız $i",$e->getMessage(),"ERROR");
					die('Bir hata oluştu: ' . $e->getMessage());
					echo $e->getMessage();
					
				}

				echo $Username .'<br>';
				sleep(10);
}

?>